public class Drv {
    public static void main(String[] args) {
        REC rec = new REC();
        rec.start();
    }
}
